package com.example.myapplication;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private List<Item> itemList = new ArrayList<>();
    private RecyclerView recyclerView;
    private ItemAdapter itemAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {//creating a new instance and adding it to the list
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        itemAdapter = new ItemAdapter(itemList);
        recyclerView.setAdapter(itemAdapter);

        fetchData();
    }

    private void fetchData() {//getting data from url
        String url = "https://fetch-hiring.s3.amazonaws.com/hiring.json";
        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {//by getting a parse the json
                        parseResponse(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {//print the error
                        error.printStackTrace();
                    }
                });

        Volley.newRequestQueue(this).add(request);
    }

    private void parseResponse(JSONArray response) {//parsing the response from json file to Strings
        itemList.clear();
        try {
            for (int i = 0; i < response.length(); i++) {
                JSONObject jsonObject = response.getJSONObject(i);
                String name = jsonObject.optString("name");
                if (!name.isEmpty()) {
                    int id = jsonObject.getInt("id");
                    int listId = jsonObject.getInt("listId");
                    itemList.add(new Item(id, listId, name));
                }
            }
            Collections.sort(itemList, new Comparator<Item>() {
                @Override
                public int compare(Item item1, Item item2) {
                    int compareListId = Integer.compare(item1.getListId(), item2.getListId());
                    return compareListId != 0 ? compareListId : item1.getName().compareTo(item2.getName());
                }
            });
            itemAdapter.setItems(itemList);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
